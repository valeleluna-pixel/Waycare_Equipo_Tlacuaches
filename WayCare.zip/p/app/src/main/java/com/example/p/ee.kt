package com.example.p

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

// It is a good practice to name classes using UpperCamelCase, e.g., "EeActivity"
class ee : AppCompatActivity() {

    // 1. Move all property declarations inside the class
    private lateinit var listHistorial: ListView
    private lateinit var listSeguras: ListView

    private val historialRutas = mutableListOf(
        "Casa (15 veces)",
        "Metro Hidalgo (9 veces)",
        "Hospital General (4 veces)",
        "Escuela (2 veces)"
    )

    private val ubicacionesSeguras = mutableListOf<String>()

    // 2. The onCreate method must be inside the class
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ee)

        listHistorial = findViewById(R.id.listHistorial)
        listSeguras = findViewById(R.id.listSeguras)

        cargarHistorial()
        cargarUbicacionesSeguras()
    }

    // 3. All related functions must also be inside the class
    private fun cargarHistorial() {
        val adapterHistorial = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            historialRutas
        )
        listHistorial.adapter = adapterHistorial
    }

    private fun cargarUbicacionesSeguras() {
        // Clear the list before adding new items to avoid duplicates if this function is called again
        ubicacionesSeguras.clear()

        // Simulación de lugares cercanos (luego esto será automático por GPS)
        ubicacionesSeguras.add("Hospital General - 250m")
        ubicacionesSeguras.add("Metro Juárez - 180m")
        ubicacionesSeguras.add("Casa de Cultura - 400m")
        ubicacionesSeguras.add("Paradero de Autobús - 120m")

        val adapterSeguras = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            ubicacionesSeguras
        )
        listSeguras.adapter = adapterSeguras
    }
}