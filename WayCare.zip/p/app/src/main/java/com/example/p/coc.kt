package com.example.p

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.SpeechRecognizer.createSpeechRecognizer
import android.speech.RecognitionListener
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class coc : AppCompatActivity() {

    private lateinit var btnIniciarGuia: Button
    private lateinit var btnZonaSegura: Button
    private lateinit var btnEmergencia: Button
    private lateinit var btnConfiguracion: Button
    private lateinit var btnAsistenteVoz: Button

    private lateinit var speechRecognizer: SpeechRecognizer
    private val REQUEST_CODE_SPEECH_INPUT = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_coc)

        // Inicializar los botones
        btnIniciarGuia = findViewById(R.id.btnIniciarGuia)
        btnZonaSegura = findViewById(R.id.btnZonaSegura)
        btnEmergencia = findViewById(R.id.btnEmergencia)
        btnConfiguracion = findViewById(R.id.btnConfiguracion)
        btnAsistenteVoz = findViewById(R.id.btnAsistenteVoz)

        // Agregar los listeners para los botones
        btnIniciarGuia.setOnClickListener {
            val intent = Intent(this, ov::class.java)
            startActivity(intent)
        }

        btnZonaSegura.setOnClickListener {
            val intent = Intent(this, ee::class.java)
            startActivity(intent)
        }

        btnEmergencia.setOnClickListener {
            showMessage("Proximamente")
        }
        btnConfiguracion.setOnClickListener {
            showMessage("Proximamente")
        }

        // Función de Asistente de voz
        btnAsistenteVoz.setOnClickListener {
            startVoiceRecognition()
        }

        // Configurar SpeechRecognizer
        speechRecognizer = createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                Toast.makeText(this@coc, "Error al reconocer la voz", Toast.LENGTH_SHORT).show()
            }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (matches != null && matches.isNotEmpty()) {
                    val result = matches[0].toLowerCase()
                    if (result.contains("emergencia")) {
                        btnEmergencia.performClick()
                    } else if (result.contains("configuracion")) {
                        btnConfiguracion.performClick()
                    } else if (result.contains("zona segura")) {
                        btnZonaSegura.performClick()
                    } else if (result.contains("iniciar guia")) {
                        btnIniciarGuia.performClick()
                    }
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    // Mostrar un mensaje de "Próximamente"
    private fun showMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    // Iniciar el reconocimiento de voz
    private fun startVoiceRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Dime el nombre del botón que deseas seleccionar")
        startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT)
    }

    // Manejar los resultados del reconocimiento de voz
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_SPEECH_INPUT && resultCode == Activity.RESULT_OK && data != null) {
            val result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (result != null && result.isNotEmpty()) {
                val voiceCommand = result[0].toLowerCase()
                if (voiceCommand.contains("emergencia")) {
                    btnEmergencia.performClick()
                } else if (voiceCommand.contains("configuracion")) {
                    btnConfiguracion.performClick()
                } else if (voiceCommand.contains("zona segura")) {
                    btnZonaSegura.performClick()
                } else if (voiceCommand.contains("iniciar guia")) {
                    btnIniciarGuia.performClick()
                }
            }
        }
    }
}