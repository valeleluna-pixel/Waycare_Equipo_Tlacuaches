package com.example.p

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.textfield.TextInputEditText
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var usernameEditText: TextInputEditText
    private lateinit var passwordEditText: TextInputEditText
    private lateinit var loginButton: Button
    private lateinit var registerText: TextView
    private lateinit var micButton: ImageButton

    // Reconocimiento de voz
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var speechIntent: android.content.Intent

    // Credenciales de ejemplo (lógica que ya traías)
    private val validUsername = "usuario"
    private val validPassword = "contraseña123"

    companion object {
        const val REQ_RECORD_AUDIO = 2001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupClickListeners()
        setupVoiceRecognizer()
    }

    private fun initViews() {
        usernameEditText = findViewById(R.id.usernameEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.loginButton)
        registerText = findViewById(R.id.registerText)
        micButton = findViewById(R.id.micButton)
    }

    private fun setupClickListeners() {
        loginButton.setOnClickListener {
            attemptLogin()
        }

        registerText.setOnClickListener {
            val intent = android.content.Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }


        micButton.setOnClickListener {
            requestMicPermissionAndListen()
        }
    }

    // ----------------------------------------------------------
    //                  CONFIGURACIÓN DE VOZ
    // ----------------------------------------------------------

    private fun setupVoiceRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        speechIntent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
            putExtra(
                RecognizerIntent.EXTRA_PROMPT,
                "Di tu usuario, contraseña o 'iniciar sesión'"
            )
        }

        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                Toast.makeText(this@MainActivity, "Error al escuchar", Toast.LENGTH_SHORT).show()
            }

            override fun onResults(results: Bundle?) {
                val matches =
                    results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull() ?: return
                val lower = text.lowercase(Locale.getDefault())

                Toast.makeText(this@MainActivity, "Escuché: $text", Toast.LENGTH_LONG).show()

                // 1) Comando directo para iniciar sesión
                if (lower.contains("iniciar sesión")) {
                    attemptLogin()
                    return
                }

                // 2) "usuario Brandon"
                if (lower.startsWith("usuario")) {
                    val value = lower.removePrefix("usuario").trim()
                    if (value.isNotEmpty()) {
                        usernameEditText.setText(value)
                        return
                    }
                }

                // 3) "contraseña uno dos tres"
                if (lower.startsWith("contraseña")) {
                    val value = lower.removePrefix("contraseña").trim()
                    if (value.isNotEmpty()) {
                        passwordEditText.setText(value)
                        return
                    }
                }

                // 4) Si no dice usuario/contraseña, llenamos automático
                if (usernameEditText.text.isNullOrEmpty()) {
                    usernameEditText.setText(text)
                } else if (passwordEditText.text.isNullOrEmpty()) {
                    passwordEditText.setText(text)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun requestMicPermissionAndListen() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            startListening()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQ_RECORD_AUDIO
            )
        }
    }

    private fun startListening() {
        Toast.makeText(this, "Escuchando...", Toast.LENGTH_SHORT).show()
        speechRecognizer.startListening(speechIntent)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == REQ_RECORD_AUDIO &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            startListening()
        } else {
            Toast.makeText(this, "Permiso de micrófono denegado", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer.destroy()
    }

    // ----------------------------------------------------------
//               LOGIN CON FIREBASE AUTH
// ----------------------------------------------------------

    private val auth = com.google.firebase.auth.FirebaseAuth.getInstance()

    private fun attemptLogin() {
        val email = usernameEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()

        if (email.isEmpty()) {
            usernameEditText.error = "Ingresa tu correo"
            return
        }

        if (password.isEmpty()) {
            passwordEditText.error = "Ingresa tu contraseña"
            return
        }

        if (password.length < 6) {
            passwordEditText.error = "La contraseña debe tener mínimo 6 caracteres"
            return
        }

        loginUser(email, password)
    }

    private fun loginUser(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                Toast.makeText(this, "¡Inicio de sesión exitoso!", Toast.LENGTH_SHORT).show()
                goToHome()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun goToHome() {
        val intent = android.content.Intent(this@MainActivity, coc::class.java)
        startActivity(intent)
        finish()
    }
}