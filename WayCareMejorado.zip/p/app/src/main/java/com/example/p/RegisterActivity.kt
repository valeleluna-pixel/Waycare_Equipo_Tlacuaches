package com.example.p

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.p.MainActivity.Companion.REQ_RECORD_AUDIO
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.Locale


class RegisterActivity : AppCompatActivity() {

    // --- Vistas ---
    private lateinit var emailInput: TextInputEditText
    private lateinit var passwordInput: TextInputEditText
    private lateinit var registerButton: Button
    private lateinit var micButton: ImageButton

    // --- Firebase ---
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    // --- Reconocimiento de Voz ---
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var speechIntent: Intent

    companion object {
        private const val REQ_RECORD_AUDIO = 2001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        // 1. Inicializar todas las vistas
        initViews()

        // 2. Configurar los listeners de los botones
        setupClickListeners()

        // 3. Configurar el reconocimiento de voz
        setupVoiceRecognizer()
    }

    private fun initViews() {
        emailInput = findViewById(R.id.registerEmail)
        passwordInput = findViewById(R.id.registerPassword)
        registerButton = findViewById(R.id.registerButton)
        // Asegúrate de que tu activity_register.xml tenga un ImageButton con este ID
        micButton = findViewById(R.id.micButton)
    }

    private fun setupClickListeners() {
        registerButton.setOnClickListener { registerUser() }
        micButton.setOnClickListener { requestMicPermissionAndListen() }
    }

    // ----------------------------------------------------------
    //                LÓGICA DE REGISTRO
    // ----------------------------------------------------------

    private fun registerUser() {
        val email = emailInput.text.toString().trim()
        val password = passwordInput.text.toString().trim()

        if (email.isEmpty()) {
            emailInput.error = "Ingresa un correo"
            return
        }
        if (password.isEmpty() || password.length < 6) {
            passwordInput.error = "Contraseña mínimo 6 caracteres"
            return
        }

        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener { authResult ->
                val userId = authResult.user!!.uid

                // CORRECCIÓN DE SEGURIDAD: Nunca guardes la contraseña en la base de datos.
                val userMap = mapOf("email" to email)

                db.collection("usuarios").document(userId).set(userMap)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show()
                        finish() // Vuelve a la pantalla de login
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(
                            this,
                            "Error al guardar datos: ${e.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error en el registro: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }

    // ----------------------------------------------------------
    //                LÓGICA DE VOZ
    // ----------------------------------------------------------

    private fun setupVoiceRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Di 'correo', 'contraseña', o 'registrarme'")
        }

        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                Toast.makeText(this@RegisterActivity, "Error al escuchar", Toast.LENGTH_SHORT)
                    .show()
            }

            override fun onResults(results: Bundle?) {
                val text =
                    results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        ?: return
                val lowerText = text.lowercase(Locale.getDefault())

                Toast.makeText(this@RegisterActivity, "Escuché: $text", Toast.LENGTH_LONG).show()

                // Comando para registrar
                if (lowerText.contains("registrarme") || lowerText.contains("registrar")) {
                    registerButton.performClick()
                    return
                }

                // Comando para llenar el correo electrónico
                if (lowerText.startsWith("correo")) {
                    // Quitamos la palabra "correo" y limpiamos espacios y puntos para formar un email
                    val emailValue = lowerText.removePrefix("correo").trim().replace(" ", "")
                        .replace("arroba", "@")
                    if (emailValue.isNotEmpty()) {
                        emailInput.setText(emailValue)
                        passwordInput.requestFocus() // Mueve el foco al siguiente campo
                    }
                    return
                }

                // Comando para llenar la contraseña
                if (lowerText.startsWith("contraseña")) {
                    val passwordValue = lowerText.removePrefix("contraseña").trim()
                    if (passwordValue.isNotEmpty()) {
                        passwordInput.setText(passwordValue)
                    }
                    return
                }

                // Si no es un comando, llena los campos en orden
                if (emailInput.text.isNullOrEmpty()) {
                    emailInput.setText(text.replace(" ", "").replace("arroba", "@"))
                } else if (passwordInput.text.isNullOrEmpty()) {
                    passwordInput.setText(text)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun requestMicPermissionAndListen() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            startListening()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQ_RECORD_AUDIO
            )
        }
    }

    private fun startListening() {
        Toast.makeText(this, "Escuchando...", Toast.LENGTH_SHORT).show()
        speechRecognizer.startListening(speechIntent)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_RECORD_AUDIO && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            Toast.makeText(this, "Permiso de micrófono denegado", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer.destroy()
    }
}



