package com.example.weycareapp

import android.graphics.*
import androidx.camera.core.ImageProxy
import android.media.Image
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import java.io.ByteArrayOutputStream
import kotlin.math.min

@OptIn(ExperimentalGetImage::class)
fun imageProxyToBitmap(imageProxy: ImageProxy): Bitmap? {
    val image: Image = imageProxy.image ?: return null
    if (image.format != ImageFormat.YUV_420_888) return null

    val nv21 = yuv420ToNv21(image)
    val yuvImage = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
    val out = ByteArrayOutputStream()
    val success = yuvImage.compressToJpeg(Rect(0, 0, image.width, image.height), 90, out)
    if (!success) return null
    val imageBytes = out.toByteArray()
    return BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
}

private fun yuv420ToNv21(image: Image): ByteArray {
    val width = image.width
    val height = image.height
    val ySize = width * height
    val uvSize = width * height / 4
    val nv21 = ByteArray(ySize + uvSize * 2)

    val yPlane = image.planes[0]
    val uPlane = image.planes[1]
    val vPlane = image.planes[2]

    val yBuffer = yPlane.buffer
    val yRowStride = yPlane.rowStride
    val yPixelStride = yPlane.pixelStride
    val y = ByteArray(yBuffer.remaining())
    yBuffer.get(y)

    if (yPixelStride == 1 && yRowStride == width) {
        System.arraycopy(y, 0, nv21, 0, ySize)
    } else {
        var outputPos = 0
        var row = 0
        while (row < height) {
            val rowStart = row * yRowStride
            for (col in 0 until width) {
                nv21[outputPos++] = y[rowStart + col * yPixelStride]
            }
            row++
        }
    }

    var outIndex = ySize
    val uBuffer = uPlane.buffer
    val vBuffer = vPlane.buffer
    val uRowStride = uPlane.rowStride
    val vRowStride = vPlane.rowStride
    val uPixelStride = uPlane.pixelStride
    val vPixelStride = vPlane.pixelStride

    val chromaHeight = height / 2
    val chromaWidth = width / 2

    val rowDataU = ByteArray(uRowStride)
    val rowDataV = ByteArray(vRowStride)

    for (row in 0 until chromaHeight) {
        val uRowOffset = row * uRowStride
        val vRowOffset = row * vRowStride

        uBuffer.position(uRowOffset)
        vBuffer.position(vRowOffset)
        val uRead = min(uRowStride, uBuffer.remaining())
        val vRead = min(vRowStride, vBuffer.remaining())
        uBuffer.get(rowDataU, 0, uRead)
        vBuffer.get(rowDataV, 0, vRead)

        for (col in 0 until chromaWidth) {
            val vIndex = col * vPixelStride
            val uIndex = col * uPixelStride
            val vb = if (vIndex < vRead) rowDataV[vIndex] else 0
            val ub = if (uIndex < uRead) rowDataU[uIndex] else 0
            nv21[outIndex++] = vb
            nv21[outIndex++] = ub
        }
    }

    return nv21
}