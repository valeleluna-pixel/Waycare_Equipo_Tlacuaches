package com.example.p

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.preference.PreferenceManager
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.util.Locale

class ov : AppCompatActivity(), TextToSpeech.OnInitListener {

    // --- Vistas ---
    private lateinit var mapView: MapView
    private lateinit var etUbicacion: EditText
    private lateinit var etBuscar: EditText
    private lateinit var btnDetenerGuia: Button
    private lateinit var btnRegresarMenu: Button
    private lateinit var btnIniciarGuiaRuta: Button
    private lateinit var btnMicBuscar: ImageButton

    // --- Ubicación ---
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private lateinit var locationRequest: LocationRequest

    // --- Voz ---
    private lateinit var tts: TextToSpeech
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var speechIntent: Intent

    // --- Mapa y Ruta ---
    private var destino: GeoPoint? = null
    private var marcadorDestino: Marker? = null
    private var marcadorUsuario: Marker? = null
    private var ruta: Polyline? = null
    private var guiaActiva = false

    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 100
        private const val MIC_PERMISSION_REQUEST_CODE = 999
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(this, PreferenceManager.getDefaultSharedPreferences(this))
        setContentView(R.layout.activity_ov)

        initViews()
        setupListeners()
        setupServices()

        checkLocationPermission() // Inicia la lógica de permisos y ubicación
    }

    private fun initViews() {
        mapView = findViewById(R.id.mapView)
        etUbicacion = findViewById(R.id.etUbicacion)
        etBuscar = findViewById(R.id.etBuscar)
        btnDetenerGuia = findViewById(R.id.btnDetenerGuia)
        btnRegresarMenu = findViewById(R.id.btnRegresarMenu)
        btnIniciarGuiaRuta = findViewById(R.id.btnIniciarGuiaRuta)
        btnMicBuscar = findViewById(R.id.btnMicBuscar)
    }

    private fun setupListeners() {
        btnRegresarMenu.setOnClickListener { finish() }
        btnMicBuscar.setOnClickListener { iniciarBusquedaPorVoz() }

        btnIniciarGuiaRuta.setOnClickListener {
            if (destino != null) {
                guiaActiva = true
                hablar("Guía iniciada")
            } else {
                hablar("Primero busca un destino")
            }
        }

        btnDetenerGuia.setOnClickListener { detenerGuia() }

        etBuscar.setOnEditorActionListener { _, _, _ ->
            buscarDireccion(etBuscar.text.toString())
            true
        }
    }

    private fun setupServices() {
        tts = TextToSpeech(this, this)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        configurarSpeechRecognizer()
        setupMap()
        setupLocation() // Llamada a la función corregida
    }

    // ▼▼▼ FUNCIÓN CORREGIDA ▼▼▼
    private fun setupLocation() {
        locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 4000).apply {
            setMinUpdateIntervalMillis(2000)
        }.build()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { actualizarUbicacion(it) }
            }
        }
    }

    //region Lógica de Voz
    private fun configurarSpeechRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Di tu destino")
        }
    }

    private fun iniciarBusquedaPorVoz() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            hablar("Escuchando...")
            startActivityForResult(speechIntent, MIC_PERMISSION_REQUEST_CODE)
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                MIC_PERMISSION_REQUEST_CODE
            )
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == MIC_PERMISSION_REQUEST_CODE && resultCode == Activity.RESULT_OK && data != null) {
            val matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val texto =
                matches?.firstOrNull()?.lowercase(Locale.getDefault()) // Convertir a minúsculas

            if (!texto.isNullOrBlank()) {
                Toast.makeText(this, "Escuché: $texto", Toast.LENGTH_LONG).show()

                // --- LÓGICA DE COMANDOS AMPLIADA ---

                // 1. Comando para regresar al menú
                if (texto.contains("regresar") || texto.contains("menú")) {
                    hablar("Regresando al menú principal")
                    btnRegresarMenu.performClick()
                    return // Salimos de la función para no procesar como una búsqueda
                }

                // 2. Si no es un comando, lo tratamos como una búsqueda de dirección
                etBuscar.setText(texto)
                buscarDireccion(texto)
                hablar("Buscando $texto")
            }
        }
    }
    //endregion

    //region Permisos
    private fun checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        } else {
            startLocationUpdates()
        }
    }

    // ▼▼▼ FUNCIÓN CORREGIDA ▼▼▼
    private fun startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        // Asegura que las variables estén inicializadas antes de usarlas
        if (!::locationRequest.isInitialized) {
            setupLocation()
        }

        fusedLocationClient.requestLocationUpdates(
            locationRequest,
            locationCallback,
            Looper.getMainLooper()
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            LOCATION_PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startLocationUpdates()
                } else {
                    hablar("Permiso de ubicación denegado. La guía no puede funcionar.")
                    Toast.makeText(this, "Permiso de ubicación denegado", Toast.LENGTH_LONG).show()
                }
            }

            MIC_PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    iniciarBusquedaPorVoz()
                } else {
                    hablar("Permiso de micrófono denegado.")
                    Toast.makeText(this, "Permiso de micrófono denegado", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    //endregion

    //region Ciclo de Vida y TTS
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("es", "MX")
            hablar("Pantalla de guía iniciada")
        }
    }

    private fun hablar(texto: String) {
        tts.speak(texto, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            startLocationUpdates()
        }
    }

    override fun onPause() {
        super.onPause()
        if (::fusedLocationClient.isInitialized && ::locationCallback.isInitialized) {
            fusedLocationClient.removeLocationUpdates(locationCallback)
        }
        mapView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        tts.shutdown()
        if (::speechRecognizer.isInitialized) {
            speechRecognizer.destroy()
        }
    }
    //endregion

    //region Lógica de Mapa y Búsqueda
    private fun setupMap() {
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true)
        mapView.controller.setZoom(16.0)
    }

    private fun actualizarUbicacion(location: Location) {
        val punto = GeoPoint(location.latitude, location.longitude)
        etUbicacion.setText("Lat: %.4f, Lng: %.4f".format(location.latitude, location.longitude))
        mapView.controller.animateTo(punto)

        if (marcadorUsuario == null) {
            marcadorUsuario = Marker(mapView).apply { title = "Tu ubicación" }
            mapView.overlays.add(marcadorUsuario)
        }
        marcadorUsuario?.position = punto

        if (guiaActiva && destino != null) {
            dibujarRuta(punto, destino!!)
            val resultados = FloatArray(1)
            Location.distanceBetween(
                location.latitude,
                location.longitude,
                destino!!.latitude,
                destino!!.longitude,
                resultados
            )
            val distancia = resultados[0]

            if (distancia <= 30f) hablar("Estás muy cerca de tu destino")
            if (distancia <= 15f) {
                hablar("Has llegado a tu destino")
                detenerGuia()
            }
        }
        mapView.invalidate()
    }

    private fun buscarDireccion(texto: String) {
        if (texto.isBlank()) {
            hablar("Por favor, di o escribe una dirección válida")
            return
        }
        try {
            val geocoder = Geocoder(this, Locale.getDefault())
            val lista = geocoder.getFromLocationName(texto, 1)

            if (lista?.isNotEmpty() == true) {
                val direccion = lista[0]
                destino = GeoPoint(direccion.latitude, direccion.longitude)

                if (marcadorDestino == null) {
                    marcadorDestino = Marker(mapView).apply { title = "Destino" }
                    mapView.overlays.add(marcadorDestino)
                }
                marcadorDestino?.position = destino
                mapView.controller.animateTo(destino)
                hablar("Destino establecido en ${direccion.getAddressLine(0)}")
            } else {
                hablar("Dirección no encontrada")
            }
        } catch (e: Exception) {
            hablar("Error al buscar la dirección")
            e.printStackTrace()
        }
        mapView.invalidate()
    }

    private fun dibujarRuta(origen: GeoPoint, destino: GeoPoint) {
        if (ruta == null) {
            ruta = Polyline().apply {
                outlinePaint.color = Color.BLUE
                outlinePaint.strokeWidth = 10f
            }
            mapView.overlays.add(0, ruta)
        }
        ruta?.setPoints(listOf(origen, destino))
    }

    private fun detenerGuia() {
        guiaActiva = false
        ruta?.let { mapView.overlays.remove(it) }
        marcadorDestino?.let { mapView.overlays.remove(it) }
        ruta = null
        marcadorDestino = null
        hablar("Guía detenida")
        mapView.invalidate()
    }
    //endregion
}