package com.example.weycareapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.util.Log
import android.util.Size
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.tensorflow.lite.Interpreter
import java.io.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import android.content.res.AssetFileDescriptor
import android.graphics.ImageFormat
import androidx.camera.core.ImageProxy
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import kotlin.math.min

// Data class para detecciones
data class Detection(val label: String, val score: Float, val rect: RectF)

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "WayCare"
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
    }

    // --- CONFIG (ajusta si tu modelo es distinto) ---
    private val MODEL_NAME = "model.tflite"
    private val LABELS_NAME = "labelmap.txt"
    private var INPUT_SIZE = 320            // AJUSTA: 300, 320, 224, etc según tu modelo
    private val SCORE_THRESHOLD = 0.4f

    // TFLite y labels
    private lateinit var interpreter: Interpreter
    private lateinit var labels: List<String>

    // UI
    private lateinit var previewView: PreviewView
    private lateinit var overlay: com.example.weycareapp.OverlayView // cambia el package si es distinto
    private lateinit var txtStatus: TextView
    private lateinit var btnTake: Button
    private lateinit var btnPreview: Button

    // Concurrency
    private val executor = Executors.newSingleThreadExecutor()

    // FileProvider / camera
    private lateinit var currentPhotoFile: File
    private lateinit var currentPhotoUri: Uri

    // Camera provider (preview opcional)
    private var cameraProvider: ProcessCameraProvider? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Vincular vistas (asegúrate que existan en tu layout)
        previewView = findViewById(R.id.previewView)
        overlay = findViewById(R.id.overlay)
        txtStatus = findViewById(R.id.txt_status)
        btnTake = findViewById(R.id.btn_take_photo)
        btnPreview = findViewById(R.id.btn_toggle)

        // Cargar modelo y labels en background
        executor.execute {
            try {
                val buf = loadModelFile(MODEL_NAME)
                interpreter = Interpreter(buf)
                labels = assets.open(LABELS_NAME).bufferedReader().readLines()
                Log.d(TAG, "Modelo y labels cargados (labels=${labels.size})")

                // Intento obtener input shape para ajustar INPUT_SIZE automáticamente (si es posible)
                try {
                    val inShape = interpreter.getInputTensor(0).shape() // ej [1,320,320,3]
                    if (inShape.size >= 3) {
                        val maybe = inShape[1]
                        if (maybe > 0) {
                            INPUT_SIZE = maybe
                            Log.d(TAG, "INPUT_SIZE ajustado a $INPUT_SIZE desde tensor")
                        }
                    }
                } catch (t: Throwable) {
                    Log.w(TAG, "No pude leer shape input: ${t.message}")
                }

                runOnUiThread { txtStatus.text = "Modelo cargado" }
            } catch (e: Exception) {
                Log.e(TAG, "Error cargando modelo/labels: ${e.message}", e)
                runOnUiThread { txtStatus.text = "Error cargando modelo" }
            }
        }

        // Botón: iniciar preview (opcional)
        btnPreview.setOnClickListener {
            if (!allPermissionsGranted()) {
                requestPermissionsLauncher.launch(REQUIRED_PERMISSIONS)
                return@setOnClickListener
            }
            startCameraPreview()
            txtStatus.text = "Preview activo"
        }

        // Botón: tomar foto
        btnTake.setOnClickListener {
            if (!allPermissionsGranted()) {
                requestPermissionsLauncher.launch(REQUIRED_PERMISSIONS)
                return@setOnClickListener
            }
            dispatchTakePictureIntent()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::interpreter.isInitialized) interpreter.close()
        executor.shutdown()
    }

    // ---------------- Permisos ----------------
    private val requestPermissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
            val camGranted = perms[Manifest.permission.CAMERA] ?: false
            if (!camGranted) {
                val shouldShow = shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)
                if (!shouldShow) {
                    txtStatus.text = "Permiso cámara denegado permanentemente. Activa en Ajustes."
                    openAppSettings()
                } else {
                    txtStatus.text = "Permiso cámara denegado."
                }
            } else {
                txtStatus.text = "Permiso cámara concedido"
            }
        }

    private fun openAppSettings() {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        i.data = Uri.fromParts("package", packageName, null)
        startActivity(i)
    }

    private fun allPermissionsGranted(): Boolean {
        return REQUIRED_PERMISSIONS.all {
            ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    // ---------------- Preview (CameraX) - opcional ----------------
    private fun startCameraPreview() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            val preview = androidx.camera.core.Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            // No procesamos frames en vivo por defecto (evitar carga)
            analysis.setAnalyzer(executor) { imageProxy ->
                imageProxy.close()
            }

            try {
                cameraProvider?.unbindAll()
                cameraProvider?.bindToLifecycle(this, androidx.camera.core.CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                Log.d(TAG, "Preview iniciado")
            } catch (e: Exception) {
                Log.e(TAG, "Error iniciando preview: ${e.message}", e)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // ---------------- Tomar foto (FileProvider) ----------------
    private fun createImageFile(): File {
        val time = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("WAYCARE_$time", ".jpg", storageDir)
    }

    private fun dispatchTakePictureIntent() {
        try {
            currentPhotoFile = createImageFile()
            currentPhotoUri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", currentPhotoFile)
            takePictureLauncher.launch(currentPhotoUri)
            txtStatus.text = "Capturando foto..."
        } catch (e: Exception) {
            Log.e(TAG, "dispatchTakePictureIntent error: ${e.message}", e)
            txtStatus.text = "Error al abrir cámara"
        }
    }

    private val takePictureLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) {
            Log.d(TAG, "Foto tomada: $currentPhotoUri")
            try {
                val inputStream: InputStream? = contentResolver.openInputStream(currentPhotoUri)
                if (inputStream == null) {
                    Log.e(TAG, "openInputStream returned null")
                    runOnUiThread { txtStatus.text = "Error leyendo foto" }
                    return@registerForActivityResult
                }
                val bitmap = BitmapFactory.decodeStream(inputStream)
                inputStream.close()
                if (bitmap == null) {
                    Log.e(TAG, "BitmapFactory.decodeStream returned null")
                    runOnUiThread { txtStatus.text = "Error decodificando foto" }
                    return@registerForActivityResult
                }
                runOnUiThread { txtStatus.text = "Procesando foto..." }
                runDetectionOnBitmap(bitmap)
            } catch (e: Exception) {
                Log.e(TAG, "Error leyendo foto: ${e.message}", e)
                runOnUiThread { txtStatus.text = "Error leyendo foto" }
            }
        } else {
            runOnUiThread { txtStatus.text = "Toma cancelada" }
        }
    }

    // ---------------- Detección sobre la foto ----------------
    private fun runDetectionOnBitmap(bitmapOriginal: Bitmap) {
        executor.execute {
            try {
                if (!::interpreter.isInitialized) {
                    Log.e(TAG, "Interpreter no inicializado")
                    runOnUiThread { txtStatus.text = "Modelo no listo" }
                    return@execute
                }

                // Resize a la entrada del modelo
                val resized = Bitmap.createScaledBitmap(bitmapOriginal, INPUT_SIZE, INPUT_SIZE, true)

                // Elegir buffer según dtype: ON/OFF automático por si el modelo pide float32
                val inDTypeName = try {
                    interpreter.getInputTensor(0).dataType().toString()
                } catch (t: Throwable) {
                    "FLOAT32"
                }
                val inputBuffer: ByteBuffer = if (inputDTypeName.contains("FLOAT")) {
                    convertBitmapToByteBuffer_float32(resized)
                } else {
                    convertBitmapToByteBuffer_uint8(resized)
                }
                Log.d(TAG, "Usando input dtype = $inputDTypeName, INPUT_SIZE = $INPUT_SIZE")

                // Preparar outputs (asumiendo modelo tipo SSD: boxes, classes, scores, num)
                val outputBoxes = Array(1) { Array(100) { FloatArray(4) } } // [1,N,4]
                val outputClasses = Array(1) { FloatArray(100) }            // [1,N]
                val outputScores = Array(1) { FloatArray(100) }             // [1,N]
                val numDetections = FloatArray(1)                           // [1]

                val outputMap: MutableMap<Int, Any> = HashMap()
                outputMap[0] = outputBoxes
                outputMap[1] = outputClasses
                outputMap[2] = outputScores
                outputMap[3] = numDetections

                // Ejecutar inferencia
                try {
                    interpreter.runForMultipleInputsOutputs(arrayOf(inputBuffer), outputMap)
                } catch (e: Exception) {
                    Log.e(TAG, "Error en inferencia: ", e)
                    runOnUiThread { txtStatus.text = "Error en inferencia: ${e.message}" }
                    return@execute
                }

                // Parse resultados y mapear a tamaño original
                val imgW = bitmapOriginal.width.toFloat()
                val imgH = bitmapOriginal.height.toFloat()
                val detections = mutableListOf<Detection>()
                val count = min(100, numDetections[0].toInt())

                for (i in 0 until count) {
                    val score = outputScores[0][i]
                    if (score < SCORE_THRESHOLD) continue
                    val cls = outputClasses[0][i].toInt()
                    val labelIndex = cls - 1
                    val label = if (labelIndex in labels.indices) labels[labelIndex] else "cls_$cls"
                    val box = outputBoxes[0][i] // [ymin, xmin, ymax, xmax] normalizado
                    val top = box[0] * imgH
                    val left = box[1] * imgW
                    val bottom = box[2] * imgH
                    val right = box[3] * imgW
                    detections.add(Detection(label, score, RectF(left, top, right, bottom)))
                }

                runOnUiThread {
                    overlay.setDetections(detections)
                    txtStatus.text = "Detección lista (${detections.size})"
                }

            } catch (e: Exception) {
                Log.e(TAG, "Error runDetectionOnBitmap:", e)
                runOnUiThread { txtStatus.text = "Error durante detección: ${e.message}" }
            }
        }
    }

    // ---------------- Convertidores ----------------
    private fun convertBitmapToByteBuffer_uint8(bitmap: Bitmap): ByteBuffer {
        val byteBuffer = ByteBuffer.allocateDirect(1 * INPUT_SIZE * INPUT_SIZE * 3)
        byteBuffer.order(ByteOrder.nativeOrder())
        val intValues = IntArray(INPUT_SIZE * INPUT_SIZE)
        bitmap.getPixels(intValues, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE)
        for (pixel in intValues) {
            val r = (pixel shr 16 and 0xFF)
            val g = (pixel shr 8 and 0xFF)
            val b = (pixel and 0xFF)
            byteBuffer.put((r).toByte())
            byteBuffer.put((g).toByte())
            byteBuffer.put((b).toByte())
        }
        byteBuffer.rewind()
        return byteBuffer
    }

    private fun convertBitmapToByteBuffer_float32(bitmap: Bitmap): ByteBuffer {
        val byteBuffer = ByteBuffer.allocateDirect(4 * INPUT_SIZE * INPUT_SIZE * 3)
        byteBuffer.order(ByteOrder.nativeOrder())
        val intValues = IntArray(INPUT_SIZE * INPUT_SIZE)
        bitmap.getPixels(intValues, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE)
        for (pixel in intValues) {
            val r = (pixel shr 16 and 0xFF) / 255.0f
            val g = (pixel shr 8 and 0xFF) / 255.0f
            val b = (pixel and 0xFF) / 255.0f
            byteBuffer.putFloat(r)
            byteBuffer.putFloat(g)
            byteBuffer.putFloat(b)
        }
        byteBuffer.rewind()
        return byteBuffer
    }

    // ---------------- Helpers ----------------
    private fun loadModelFile(filename: String): MappedByteBuffer {
        val fileDescriptor: AssetFileDescriptor = assets.openFd(filename)
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        val startOffset = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }
}