package com.example.weycareapp

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

data class Detection(val label: String, val score: Float, val rect: RectF)

class OverlayView(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    private val paint = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
        color = Color.GREEN
        isAntiAlias = true
    }
    private val textBg = Paint().apply { color = Color.GREEN; style = Paint.Style.FILL }
    private val textPaint = Paint().apply { color = Color.BLACK; textSize = 40f; isAntiAlias = true }

    private var detections: List<Detection> = emptyList()

    fun setDetections(d: List<Detection>) {
        this.detections = d
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (d in detections) {
            val r = d.rect
            canvas.drawRect(r, paint)
            val text = "${d.label} ${"%.2f".format(d.score)}"
            val w = textPaint.measureText(text)
            val x = r.left
            val y = (r.top - 10f).coerceAtLeast(textPaint.textSize)
            canvas.drawRect(x, y - textPaint.textSize, x + w + 8f, y + 4f, textBg)
            canvas.drawText(text, x + 4f, y, textPaint)
        }
    }
}