package com.example.p

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.preference.PreferenceManager
import com.google.android.gms.location.*
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.util.*

class ov : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private lateinit var locationRequest: LocationRequest

    private lateinit var mapView: MapView
    private lateinit var etUbicacion: EditText
    private lateinit var etBuscar: EditText
    private lateinit var btnDetenerGuia: Button

    private lateinit var tts: TextToSpeech

    private var destino: GeoPoint? = null
    private var marcadorDestino: Marker? = null
    private var marcadorUsuario: Marker? = null
    private var ruta: Polyline? = null

    private lateinit var btnRegresarMenu: Button
    private lateinit var btnBuscarPorVoz: Button
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var speechIntent: Intent

    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 100
        private const val MIC_PERMISSION_REQUEST_CODE = 999
        private lateinit var btnIniciarGuiaRuta: Button
        private var guiaActiva = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Configuration.getInstance().load(
            applicationContext,
            PreferenceManager.getDefaultSharedPreferences(applicationContext)
        )

        setContentView(R.layout.activity_ov)

        // Inicialización de Vistas
        mapView = findViewById(R.id.mapView)
        etUbicacion = findViewById(R.id.etUbicacion)
        etBuscar = findViewById(R.id.etBuscar)
        btnDetenerGuia = findViewById(R.id.btnDetenerGuia)
        btnRegresarMenu = findViewById(R.id.btnRegresarMenu)
        btnBuscarPorVoz = findViewById(R.id.btnBuscarPorVoz)
        btnIniciarGuiaRuta = findViewById(R.id.btnIniciarGuiaRuta)

        // Listeners de botones
        btnRegresarMenu.setOnClickListener {
            finish() // Vuelve al menú anterior
        }
        btnBuscarPorVoz.setOnClickListener {
            iniciarBusquedaPorVoz()
        }
        btnIniciarGuiaRuta.setOnClickListener {
            if (destino != null) {
                guiaActiva = true
                hablar("Guía iniciada")
                Toast.makeText(this, "Guía iniciada", Toast.LENGTH_SHORT).show()
            } else {
                hablar("Primero busca un destino")
            }
        }
        btnDetenerGuia.setOnClickListener {
            detenerGuia()
        }

        // --- Configuraciones ---
        tts = TextToSpeech(this, this)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        configurarSpeechRecognizer()
        setupMap()
        setupLocation()
        setupSearch()
        checkLocationPermission() // Inicia la lógica de permisos y ubicación
    }

    //region Ciclo de Vida y TTS
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("es", "MX")
            hablar("Pantalla de guía iniciada")
        }
    }

    private fun hablar(texto: String) {
        tts.speak(texto, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
        startLocationUpdates() // Reanuda las actualizaciones de ubicación si ya hay permiso
    }

    override fun onPause() {
        super.onPause()
        fusedLocationClient.removeLocationUpdates(locationCallback)
        mapView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        tts.shutdown()
        speechRecognizer.destroy()
    }
    //endregion

    //region Configuración Inicial (Setup)
    private fun setupMap() {
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true)
        mapView.controller.setZoom(16.0)
    }

    private fun setupLocation() {
        locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 4000).build()
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                actualizarUbicacion(result.lastLocation)
            }
        }
    }

    private fun setupSearch() {
        etBuscar.setOnEditorActionListener { _, _, _ ->
            buscarDireccion(etBuscar.text.toString())
            true
        }
    }
    //endregion

    //region Lógica de Ubicación y Guía
    private fun actualizarUbicacion(location: Location?) {
        if (location == null) return

        val punto = GeoPoint(location.latitude, location.longitude)
        etUbicacion.setText("Lat: ${location.latitude}, Lng: ${location.longitude}")
        mapView.controller.animateTo(punto)

        if (marcadorUsuario == null) {
            marcadorUsuario = Marker(mapView).apply {
                title = "Tu ubicación"
                // Aquí podrías poner un ícono personalizado si quisieras
            }
            mapView.overlays.add(marcadorUsuario)
        }
        marcadorUsuario!!.position = punto

        if (guiaActiva && destino != null) {
            dibujarRuta(punto, destino!!)

            val resultados = FloatArray(1)
            Location.distanceBetween(
                location.latitude, location.longitude,
                destino!!.latitude, destino!!.longitude,
                resultados
            )
            val distancia = resultados[0]

            if (distancia <= 30f) {
                hablar("Estás muy cerca de tu destino")
            }
            if (distancia <= 15f) {
                hablar("Has llegado a tu destino")
                Toast.makeText(this, "Llegaste", Toast.LENGTH_LONG).show()
                detenerGuia()
            }
        }
        mapView.invalidate()
    }

    private fun detenerGuia() {
        guiaActiva = false
        ruta?.let { mapView.overlays.remove(it) }
        marcadorDestino?.let { mapView.overlays.remove(it) }
        ruta = null
        marcadorDestino = null // Limpiar las referencias

        hablar("Guía detenida")
        Toast.makeText(this, "Guía detenida", Toast.LENGTH_SHORT).show()
        mapView.invalidate()
    }
    //endregion

    //region Búsqueda (Texto y Voz)
    private fun buscarDireccion(texto: String) {
        if (texto.isBlank()) {
            hablar("Por favor, di una dirección válida")
            return
        }
        try {
            val geocoder = Geocoder(this, Locale.getDefault())
            val lista = geocoder.getFromLocationName(texto, 1)

            if (!lista.isNullOrEmpty()) {
                val direccion = lista[0]
                destino = GeoPoint(direccion.latitude, direccion.longitude)

                if (marcadorDestino == null) {
                    marcadorDestino = Marker(mapView).apply { title = "Destino" }
                    mapView.overlays.add(marcadorDestino)
                }
                marcadorDestino!!.position = destino
                mapView.controller.animateTo(destino)

                hablar("Destino establecido en ${direccion.getAddressLine(0)}")
            } else {
                hablar("Dirección no encontrada")
            }
        } catch (e: Exception) {
            hablar("Error al buscar la dirección")
            e.printStackTrace()
        }
        mapView.invalidate()
    }

    private fun configurarSpeechRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechIntent =
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Di tu destino")
            }

        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                hablar("Error al escuchar, intenta de nuevo")
            }

            override fun onResults(results: Bundle?) {
                val texto =
                    results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull() ?: return
                etBuscar.setText(texto)
                buscarDireccion(texto)
                hablar("Buscando $texto")
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }
    //endregion

    //region Dibujo en Mapa
    private fun dibujarRuta(origen: GeoPoint, destino: GeoPoint) {
        if (ruta == null) {
            ruta = Polyline().apply {
                outlinePaint.color = Color.BLUE
                outlinePaint.strokeWidth = 10f
            }
            mapView.overlays.add(
                0,
                ruta
            ) // Añadir al principio para que esté debajo de los marcadores
        }
        ruta?.setPoints(listOf(origen, destino))
    }
    //endregion

    //region Lógica de Permisos
    private fun checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        } else {
            startLocationUpdates()
        }
    }

    private fun iniciarBusquedaPorVoz() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            hablar("Escuchando...")
            speechRecognizer.startListening(speechIntent)
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                MIC_PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Si por alguna razón la función es llamada sin permisos, no hacer nada.
            return
        }
        fusedLocationClient.requestLocationUpdates(
            locationRequest,
            locationCallback,
            Looper.getMainLooper()
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            LOCATION_PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startLocationUpdates()
                } else {
                    hablar("Permiso de ubicación denegado. La guía no puede funcionar sin ubicación.")
                    Toast.makeText(this, "Permiso de ubicación denegado", Toast.LENGTH_LONG).show()
                }
            }

            MIC_PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Si se concede el permiso, intentar la búsqueda por voz de nuevo.
                    iniciarBusquedaPorVoz()
                } else {
                    hablar("Permiso de micrófono denegado.")
                    Toast.makeText(this, "Permiso de micrófono denegado", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    //endregion
}